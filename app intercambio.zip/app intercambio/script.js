function entrar() {
    window.location.href = "regustrotimeswap.html"
}