import group28 from './assets/Group 28.png';
import episodiodestacado from './assets/Group 1 (12).png';
import './App.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeadphones } from '@fortawesome/free-solid-svg-icons';

function App() {
  return (
    <>
      <Nav />
      <Cta />
    </>
  );
}

function Nav() {
  return (
    <div className='nav'>
      <img src={group28} alt="Logo" id='logoicon' />
      <h1 className='Logo'>Enfocando la luz</h1>
      <ul className='menu'>
        <li>Inicio</li>
        <li>Episodios</li>
        <li>Contacto</li>
      </ul>
    </div>
  );
}

function Cta() {
  return (
    <div className='cta'>
      <img src={episodiodestacado} alt="Episodio destacado" />
      <h2>Episodio 1 - El principio en la fotografía</h2>
      <p>
        En este episodio te contamos todo lo que necesitas saber para empezar en la fotografía con buen pie. 
        Hablamos de los primeros pasos, de cómo elegir tu equipo inicial, y compartimos consejos prácticos 
        para que tu aprendizaje sea más efectivo y divertido. Además, te damos ideas para evitar los errores 
        más comunes y cómo desarrollar tu propio estilo desde el principio. Si quieres iniciarte en el mundo 
        de la fotografía y sentirte seguro mientras aprendes, este episodio es para ti.
      </p>
      <a target='_blank' href="https://www.ivoox.com/episodio-1-el-principio-fotografia-audios-mp3_rf_160157252_1.html">
      <button>
        <FontAwesomeIcon icon={faHeadphones} /> Escuchar episodio
      </button>
      </a>

      
    </div>
  );
}

export default App;
